# Business Web Hero — Media Pack

Includes EN/FR video scripts + simple storyboard notes.
