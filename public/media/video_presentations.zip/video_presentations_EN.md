BusinessWebHero Video #1 (Offer) — script outline included.
BusinessWebHero Video #2 (Phase 1 vs Phase 2) — script outline included.
